package com.example.demo.controllers;

import com.example.demo.MainApplication;
import com.example.demo.models.ReservationDetails;
import com.example.demo.util.Systemlogger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import com.example.demo.util.Systemlogger;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class KioskGuestSelectionController {

    @FXML
    private Spinner<Integer> adultsSpinner;

    @FXML
    private Spinner<Integer> childrenSpinner;

    @FXML
    private Label totalGuestsLabel;

    @FXML
    private Label validationMessageLabel;

    private ReservationDetails reservationDetails;

    private final Logger logger = Systemlogger.getLogger();

    @FXML
    public void initialize() {
        // Initialize spinners
        adultsSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10, 0));
        childrenSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10, 0));

        // Add listeners to update the total guests label
        adultsSpinner.valueProperty().addListener((obs, oldValue, newValue) -> updateGuests());
        childrenSpinner.valueProperty().addListener((obs, oldValue, newValue) -> updateGuests());

        // Initial update
        updateGuests();
    }

    public void setReservationDetails(ReservationDetails reservation) {
        this.reservationDetails = reservation;
        if (this.reservationDetails != null) {
            adultsSpinner.getValueFactory().setValue(reservation.getNumberOfAdults());
            childrenSpinner.getValueFactory().setValue(reservation.getNumberOfChildren());
        }
    }

    @FXML
    private void handleBack(ActionEvent event) throws IOException {
        MainApplication.loadDateSelectionScene(reservationDetails);
    }

    @FXML
    private void handleSearchRooms(ActionEvent event) throws IOException {
        validationMessageLabel.setText("");
        int adults = adultsSpinner.getValue();
        int children = childrenSpinner.getValue();

        if (adults + children == 0) {
            validationMessageLabel.setText("You must have at least one guest to continue.");
            return;
        }

        if (reservationDetails == null) {
            reservationDetails = new ReservationDetails(null, null, adults, children);
        } else {
            reservationDetails.setNumberOfAdults(adults);
            reservationDetails.setNumberOfChildren(children);
        }

        // In a real application, this would load the next scene, which is KioskRoomSelection.
        MainApplication.loadRoomSelectionScene(reservationDetails);
    }

    @FXML
    private void handleClear(ActionEvent event) {
        adultsSpinner.getValueFactory().setValue(0);
        childrenSpinner.getValueFactory().setValue(0);
        validationMessageLabel.setText("");
    }

    @FXML
    private void handleViewRules(ActionEvent event) {
        logger.log(Level.INFO, "Displaying Rules & Regulations...");
        String rulesText = "• Single room: Max two people.\n\n" +
                "• Double room: Max 4 people.\n\n" +
                "• Deluxe and Pent rooms: Max two people but the prices are higher.\n\n" +
                "• More than 2 adults less than 5 can have Double room or two single rooms will be offered.\n\n" +
                "• More than 4 adults will have multiple Double or combination of Double and single rooms.";

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Rules and Regulations");
        alert.setHeaderText("Hotel Room Booking Rules");

        TextArea textArea = new TextArea(rulesText);
        textArea.setEditable(false);
        textArea.setWrapText(true);
        textArea.setPrefHeight(200);
        textArea.setPrefWidth(400);

        alert.getDialogPane().setContent(textArea);
        alert.getDialogPane().setPrefWidth(500);
        alert.setResizable(true);

        alert.showAndWait();
    }

    @FXML
    private void updateGuests() {
        if (adultsSpinner != null && childrenSpinner != null && totalGuestsLabel != null) {
            int totalGuests = adultsSpinner.getValue() + childrenSpinner.getValue();
            totalGuestsLabel.setText("Total Guests: " + totalGuests);
        } else {
            // This is a safety check and should not be reached with the correct FXML.
            System.err.println("One of the FXML elements is null. Check your FXML file.");
        }
    }
}
